#include "types.h"
#include "stat.h"
#include "user.h"

int main (void) {
    getReadCount();
    printf(1,"read count success");
    exit();
}
